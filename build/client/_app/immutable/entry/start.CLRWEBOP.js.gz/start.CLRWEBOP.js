import{l as o,a as r}from"../chunks/CD4_cIdr.js";export{o as load_css,r as start};

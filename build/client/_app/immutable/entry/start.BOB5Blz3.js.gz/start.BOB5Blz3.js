import{l as o,a as r}from"../chunks/Du0H-1DZ.js";export{o as load_css,r as start};
